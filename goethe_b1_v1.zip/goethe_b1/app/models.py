"""نماذج قاعدة البيانات لتطبيق Goethe B1 Prep."""
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """المستخدم / الطالب."""
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120))
    target_exam_date = db.Column(db.Date)
    level = db.Column(db.String(20), default='B1')  # B1, B2...
    daily_goal_minutes = db.Column(db.Integer, default=30)
    xp = db.Column(db.Integer, default=0)
    streak_days = db.Column(db.Integer, default=0)
    last_active = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    progress = db.relationship('Progress', backref='user', lazy='dynamic')
    vocab_progress = db.relationship('VocabProgress', backref='user', lazy='dynamic')
    exercise_attempts = db.relationship('ExerciseAttempt', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Chapter(db.Model):
    """الفصل (Kapitel)."""
    __tablename__ = 'chapters'
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer, unique=True, nullable=False)  # 1..12
    title_de = db.Column(db.String(120), nullable=False)
    title_ar = db.Column(db.String(200), nullable=False)
    icon = db.Column(db.String(10))
    description_de = db.Column(db.Text)
    description_ar = db.Column(db.Text)
    page_start = db.Column(db.Integer)
    page_end = db.Column(db.Integer)

    topics = db.relationship('Topic', backref='chapter', lazy='dynamic',
                             order_by='Topic.order_index')


class Topic(db.Model):
    """موضوع داخل الفصل (مثل Urlaubsarten)."""
    __tablename__ = 'topics'
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapters.id'), nullable=False)
    name_de = db.Column(db.String(120), nullable=False)
    name_ar = db.Column(db.String(200), nullable=False)
    icon = db.Column(db.String(10))
    order_index = db.Column(db.Integer, default=0)

    vocab = db.relationship('Vocabulary', backref='topic', lazy='dynamic')
    dialogues = db.relationship('Dialogue', backref='topic', lazy='dynamic')


class Vocabulary(db.Model):
    """كلمة أو عبارة مع ترجمتها ومثالها."""
    __tablename__ = 'vocabulary'
    id = db.Column(db.Integer, primary_key=True)
    topic_id = db.Column(db.Integer, db.ForeignKey('topics.id'), nullable=False)
    word_de = db.Column(db.String(200), nullable=False)
    translation_ar = db.Column(db.String(300), nullable=False)
    example_de = db.Column(db.Text)
    word_type = db.Column(db.String(50))  # Nomen, Verb, Adjektiv...
    plural = db.Column(db.String(100))
    conjugation = db.Column(db.String(100))
    audio_url = db.Column(db.String(300))
    difficulty = db.Column(db.Integer, default=1)  # 1=سهل، 3=صعب


class Dialogue(db.Model):
    """حوار."""
    __tablename__ = 'dialogues'
    id = db.Column(db.Integer, primary_key=True)
    topic_id = db.Column(db.Integer, db.ForeignKey('topics.id'), nullable=False)
    title_de = db.Column(db.String(200))
    title_ar = db.Column(db.String(300))
    situation_de = db.Column(db.Text)
    situation_ar = db.Column(db.Text)

    lines = db.relationship('DialogueLine', backref='dialogue', lazy='dynamic',
                            order_by='DialogueLine.line_index')


class DialogueLine(db.Model):
    """سطر واحد في الحوار."""
    __tablename__ = 'dialogue_lines'
    id = db.Column(db.Integer, primary_key=True)
    dialogue_id = db.Column(db.Integer, db.ForeignKey('dialogues.id'), nullable=False)
    line_index = db.Column(db.Integer, nullable=False)
    speaker = db.Column(db.String(50))  # A, B, K, R...
    text_de = db.Column(db.Text, nullable=False)
    text_ar = db.Column(db.Text, nullable=False)
    audio_url = db.Column(db.String(300))


class Grammar(db.Model):
    """قاعدة نحوية."""
    __tablename__ = 'grammar'
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapters.id'), nullable=False)
    title_de = db.Column(db.String(200), nullable=False)
    title_ar = db.Column(db.String(300), nullable=False)
    explanation_de = db.Column(db.Text)
    explanation_ar = db.Column(db.Text)
    examples_json = db.Column(db.Text)  # JSON list of examples
    order_index = db.Column(db.Integer, default=0)


class UsefulPhrase(db.Model):
    """تعبير مفيد (Redemittel)."""
    __tablename__ = 'useful_phrases'
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapters.id'), nullable=False)
    category = db.Column(db.String(100))  # im_reisebuero, am_bahnhof...
    phrase_de = db.Column(db.String(300), nullable=False)
    phrase_ar = db.Column(db.String(400), nullable=False)


class Exercise(db.Model):
    """تمرين تفاعلي."""
    __tablename__ = 'exercises'
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapters.id'), nullable=False)
    skill = db.Column(db.String(50))  # lesen, hoeren, schreiben, sprechen, wortschatz, grammatik
    question_type = db.Column(db.String(50))  # multiple_choice, fill_blank, match...
    question_de = db.Column(db.Text)
    question_ar = db.Column(db.Text)
    options_json = db.Column(db.Text)
    correct_answer = db.Column(db.String(500))
    explanation = db.Column(db.Text)
    difficulty = db.Column(db.Integer, default=1)


class Progress(db.Model):
    """تقدم الطالب في الفصول."""
    __tablename__ = 'progress'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapters.id'), nullable=False)
    status = db.Column(db.String(20), default='locked')  # locked, unlocked, in_progress, completed
    completion_percent = db.Column(db.Integer, default=0)
    last_accessed = db.Column(db.DateTime, default=datetime.utcnow)


class VocabProgress(db.Model):
    """تقدم حفظ المفردات (نظام مراجعة ذكي مبسّط)."""
    __tablename__ = 'vocab_progress'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    vocab_id = db.Column(db.Integer, db.ForeignKey('vocabulary.id'), nullable=False)
    times_seen = db.Column(db.Integer, default=0)
    times_correct = db.Column(db.Integer, default=0)
    times_wrong = db.Column(db.Integer, default=0)
    mastery_level = db.Column(db.Integer, default=0)  # 0..5
    next_review = db.Column(db.DateTime, default=datetime.utcnow)
    last_reviewed = db.Column(db.DateTime)


class ExerciseAttempt(db.Model):
    """محاولة حل تمرين."""
    __tablename__ = 'exercise_attempts'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    exercise_id = db.Column(db.Integer, db.ForeignKey('exercises.id'), nullable=False)
    is_correct = db.Column(db.Boolean, default=False)
    user_answer = db.Column(db.Text)
    attempted_at = db.Column(db.DateTime, default=datetime.utcnow)
