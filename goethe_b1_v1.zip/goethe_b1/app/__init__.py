"""تهيئة تطبيق Flask."""
from flask import Flask
from flask_login import LoginManager
from .models import db, User


login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'الرجاء تسجيل الدخول أولاً'
login_manager.login_message_category = 'info'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'dev-secret-change-in-prod'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///goethe_b1.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    login_manager.init_app(app)

    from .routes.main import main_bp
    from .routes.auth import auth_bp
    from .routes.chapter import chapter_bp
    from .routes.practice import practice_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(chapter_bp, url_prefix='/chapter')
    app.register_blueprint(practice_bp, url_prefix='/practice')

    with app.app_context():
        db.create_all()

    return app
