"""صفحات التدريب والتمارين."""
from flask import Blueprint, render_template
from flask_login import login_required

practice_bp = Blueprint('practice', __name__)


@practice_bp.route('/')
@login_required
def index():
    """صفحة اختيار نوع التدريب."""
    return render_template('practice/index.html')


@practice_bp.route('/vocabulary')
@login_required
def vocabulary():
    """تدريب المفردات (Flashcards)."""
    return render_template('practice/vocabulary.html')


@practice_bp.route('/mock-exam')
@login_required
def mock_exam():
    """محاكاة امتحان Goethe B1."""
    return render_template('practice/mock_exam.html')


@practice_bp.route('/sprechen')
@login_required
def sprechen():
    """تدريب المحادثة."""
    return render_template('practice/sprechen.html')
