"""صفحات الفصول والمواضيع والمفردات والحوارات."""
from flask import Blueprint, render_template, abort
from flask_login import login_required
from ..models import Chapter, Topic, Vocabulary, Dialogue, Grammar, UsefulPhrase, db

chapter_bp = Blueprint('chapter', __name__)


@chapter_bp.route('/<int:number>')
@login_required
def detail(number):
    """عرض ملخص الفصل."""
    chapter = Chapter.query.filter_by(number=number).first_or_404()
    topics = chapter.topics.all()
    grammars = chapter.grammar.order_by(Grammar.order_index).all() if hasattr(chapter, 'grammar') else []
    phrases = UsefulPhrase.query.filter_by(chapter_id=chapter.id).all()

    # عدّاد المفردات لكل موضوع
    topic_vocab_counts = {}
    for t in topics:
        topic_vocab_counts[t.id] = t.vocab.count()

    return render_template('chapter/detail.html',
                           chapter=chapter,
                           topics=topics,
                           grammars=grammars,
                           phrases=phrases,
                           topic_vocab_counts=topic_vocab_counts)


@chapter_bp.route('/<int:number>/topic/<int:topic_id>')
@login_required
def topic(number, topic_id):
    """عرض موضوع: مفردات + حوارات."""
    chapter = Chapter.query.filter_by(number=number).first_or_404()
    topic = Topic.query.filter_by(id=topic_id, chapter_id=chapter.id).first_or_404()
    vocab = topic.vocab.order_by(Vocabulary.id).all()
    dialogues = topic.dialogues.all()
    return render_template('chapter/topic.html',
                           chapter=chapter,
                           topic=topic,
                           vocab=vocab,
                           dialogues=dialogues)


@chapter_bp.route('/<int:number>/vocabulary')
@login_required
def vocabulary_list(number):
    """كل مفردات الفصل في صفحة واحدة."""
    chapter = Chapter.query.filter_by(number=number).first_or_404()
    topics = chapter.topics.all()
    vocab_by_topic = {t.id: t.vocab.order_by(Vocabulary.id).all() for t in topics}
    return render_template('chapter/vocabulary.html',
                           chapter=chapter,
                           topics=topics,
                           vocab_by_topic=vocab_by_topic)
